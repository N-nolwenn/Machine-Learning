import numpy as np
import matplotlib.pyplot as plt
import random as rd

from mltools import plot_data, plot_frontiere, make_grid, gen_arti

def mse(w, x, y):
	""" Renvoie le coût aux moindres carrés pour une fonction linéaire de 
		paramètres w de taille (d) sur les données x de taille (n,d) et les 
		labels y (n).
	"""
	w = w.reshape(-1,1)
	y = y.reshape(-1,1)
	
	return (y - np.dot(x,w))**2

def reglog(w, x, y):
	""" Renvoie le coût pour une régression logistique sur des paramètre w de
		taille (d), x de taille (n,d) et y (n).
	"""
	w = w.reshape(-1,1)
	y = y.reshape(-1,1)
	
	fw = np.dot(x,w)
	return np.log( 1 + np.exp( -y * fw) )

def mse_grad(w, x, y):
	""" Renvoie le gradient des moindres carrés sous la forme d'une 
		matrice (n,d).
	"""
	w = w.reshape(-1,1)
	y = y.reshape(-1,1)
	
	return -2 * x * (y - np.dot(x,w))

def reglog_grad(w, x, y):
	""" Renvoie le gradient de la régression logistique sous la forme d'une
		matrice (n,d).
	"""
	w = w.reshape(-1,1)
	y = y.reshape(-1,1)
	
	fw = np.dot(x,w)
	return (- y * x ) / ( 1 + np.exp( y * fw ) )

def check_fonctions():
	## On fixe la seed de l'aléatoire pour vérifier les fonctions
	np.random.seed(0)
	datax, datay = gen_arti(epsilon=0.1)
	wrandom = np.random.randn(datax.shape[1],1)
	assert(np.isclose(mse(wrandom,datax,datay).mean(),0.54731,rtol=1e-4))
	assert(np.isclose(reglog(wrandom,datax,datay).mean(), 0.57053,rtol=1e-4))
	assert(np.isclose(mse_grad(wrandom,datax,datay).mean(),-1.43120,rtol=1e-4))
	assert(np.isclose(reglog_grad(wrandom,datax,datay).mean(),-0.42714,rtol=1e-4))
	np.random.seed()

def descente_gradient(datax, datay, f_loss, f_grad, eps=0.01, iter=100, descent='batch', minibatch = 10):
	""" Réalise une descent de gradient pour optimier le coût f_loss (de 
		gradient f_grad) sur les données datax et les labels datay, avec un 
		pas de descente de eps et iter itérations.
		@return w: array, w optimal trouvé au bout de iter itérations
		@return allw: list(array), liste des w successivement calculés
		@return allf: list(float), liste des coût pour toutes les itérations
	"""
	# Initialisation de w, allw, allf
	w = np.zeros((1, len(datax[0])))
	allw = [ w[0].tolist() ]							# tous les w calculés
	allf = [ np.mean( f_loss( w, datax, datay ) ) ]	 # tous les coûts
	
	for niter in range(iter):
		if descent == 'batch':
			# On moyenne les ∂f/∂wi pour chaque dimension i ∈ [1,d] 
			delta = np.mean( f_grad( w, datax, datay), axis = 0 )
			w -= eps * delta
		if descent == 'stochastique':
			# On tire au hasard un exemple de datax et on met à jour w
			i = rd.randint(0, len(datax)-1)
			x = datax[i]
			y = datay[i]
			w -= eps * f_grad( w, x, y)
		if descent == 'mini-batch':
			inds = [rd.randint(0,len(datax)-1) for i in range(minibatch)]
			delta = np.mean( [ f_grad( w, datax[i], datay[i]) for i in inds], axis = 0 )
			w -= eps * delta
			
		# Mise à jour de allw et allf
		allw.append( w[0].tolist() )
		allf.append(np.mean( f_loss( w, datax, datay ) ) )
		
	return w, allw, allf

def plot_grad(datax, datay, col, descent, eps=0.01, iter=100):
	w, allw, allf = descente_gradient(datax, datay, mse, mse_grad, eps, iter, descent)

	# Affichage de w
	print("---------"+descent+"---------")
	print('Première valeur de w: ', allw[0])
	print('Valeur optimal w* : ', w)

	# Affichage de la 1ère et de la dernière valeur du coût
	print('Coût de départ:', allf[0])
	print('Coût optimum:', allf[-1])

	# Plot de la fonction coût au fil des itérations: descente de gradient batch
	plt.figure()
	plt.title("Evolution du coût au fil des itérations pour " + str(descent))
	plt.xlabel('Itérations')
	plt.ylabel('Valeur du coût')
	plt.plot(allf, label = descent, color=col)

def	plot_reglin(xtrain, ytrain, xtest, ytest, eps, iter, descent):
	w_reglin, allw_reglin, allf_reglin = descente_gradient(xtrain, ytrain, mse, mse_grad, eps, iter,  descent)
	w_reglin = w_reglin.reshape(xtrain.shape[1],1)

	# Visualisation des données et de la frontière de décision pour XTRAIN
	plt.figure()
	plt.title('RegLin : Frontière de décision pour xtrain avec eps=' + str(eps))
	plt.xlabel('xtrain')
	plt.ylabel('ytrain')
	
	plot_frontiere(xtrain,lambda x : np.sign(x.dot(w_reglin)),step=100)
	plot_data(xtrain,ytrain)

	##Visualisation des données et de la frontière de décision pour XTEST
	plt.figure()
	plt.title('RegLin : Frontière de décision pour xtest avec eps=' + str(eps))
	plt.xlabel('xtest')
	plt.ylabel('ytest')
	w_reglin = w_reglin.reshape(xtrain.shape[1],1)
	plot_frontiere(xtest,lambda x : np.sign(x.dot(w_reglin)),step=100)
	plot_data(xtest,ytest)

	## Visualisation de la fonction de coût en 2D
	plt.figure()
	plt.title('RegLin : Visualisation de la fonction de coût en 2D avec eps=' + str(eps))
	plt.contourf(x_grid,y_grid,np.array([mse(w_reglin,xtrain,ytrain).mean() for w_reglin in grid]).reshape(x_grid.shape),levels=20)

def	plot_reglog(xtrain, ytrain, xtest, ytest, eps, iter, descent):
	w_reglog, allw_reglog, allf_reglog = descente_gradient(xtrain, ytrain, reglog, reglog_grad, eps, iter, descent)
	w_reglog = w_reglog.reshape(xtrain.shape[1],1)

	# Visualisation des données et de la frontière de décision pour XTRAIN
	plt.figure()
	plt.title('RegLog : Frontière de décision pour xtrain avec eps=' + str(eps))
	plt.xlabel('xtrain')
	plt.ylabel('ytrain')
	
	plot_frontiere(xtrain,lambda x : np.sign(x.dot(w_reglog)),step=100)
	plot_data(xtrain,ytrain)

	##Visualisation des données et de la frontière de décision pour XTEST
	plt.figure()
	plt.title('RegLog : Frontière de décision pour xtest avec eps=' + str(eps))
	plt.xlabel('xtest')
	plt.ylabel('ytest')
	w_reglog = w_reglog.reshape(xtrain.shape[1],1)
	plot_frontiere(xtest,lambda x : np.sign(x.dot(w_reglog)),step=100)
	plot_data(xtest,ytest)

	## Visualisation de la fonction de coût en 2D
	plt.figure()
	plt.title('RegLog : Visualisation de la fonction de coût en 2D avec eps=' + str(eps))
	plt.contourf(x_grid,y_grid,np.array([mse(w_reglog,xtrain,ytrain).mean() for w_reglog in grid]).reshape(x_grid.shape),levels=20)

if __name__=="__main__":
	check_fonctions()
	## Tirage d'un jeu de données aléatoire avec un bruit de 0.1
	datax, datay = gen_arti(epsilon=0.1)
	## Fabrication d'une grille de discrétisation pour la visualisation de la fonction de coût
	grid, x_grid, y_grid = make_grid(xmin=-2, xmax=2, ymin=-2, ymax=2, step=100)
	
	plt.figure()
	plt.title('Visualisation des données et de la frontière de décision pour un vecteur de poids w')
	plt.xlabel('datax')
	plt.ylabel('datay')
	## Visualisation des données et de la frontière de décision pour un vecteur de poids w
	w  = np.random.randn(datax.shape[1],1)
	plot_frontiere(datax,lambda x : np.sign(x.dot(w)),step=100)
	plot_data(datax,datay)

	## Visualisation de la fonction de coût en 2D
	plt.figure()
	plt.title('Visualisation de la fonction de coût en 2D')
	plt.contourf(x_grid,y_grid,np.array([mse(w,datax,datay).mean() for w in grid]).reshape(x_grid.shape),levels=20)
	
	# ---------------------- Descente de gradient ---------------------- #
	# Descente de gradient batch
	plot_grad(datax, datay, 'violet', descent='batch', eps=0.01, iter=100)

	# Descente de gradient stochastique
	plot_grad(datax, datay, 'khaki', descent='stochastique', eps=0.01, iter=100)

	# Descente de gradient mini-batch
	plot_grad(datax, datay, 'teal', descent='mini-batch', eps=0.01, iter=100)

	# Génération des données (1000 exemples suivant 2 gaussiennes)
	xtrain, ytrain = gen_arti(epsilon=0.1, nbex=1000)
	xtest, ytest = gen_arti(epsilon=0.1, nbex=1000)

	# ---------------------- Descente de gradient RegLin ---------------------- #
	# Evolution du cout en fonction des itérations
	epsilon = [0.00001, 0.001, 0.1, 0.5]
	for eps in epsilon:
		plot_reglin( xtrain, ytrain, xtest, ytest, eps, iter=1000, descent='batch')
	# ---------------------- Descente de gradient RegLog ---------------------- #
	# Evolution du cout en fonction des itérations
	epsilon = [0.00001, 0.001, 0.1, 0.5]
	for eps in epsilon:
		plot_reglog( xtrain, ytrain, xtest, ytest, eps, iter=1000, descent='batch')
	
	
	
